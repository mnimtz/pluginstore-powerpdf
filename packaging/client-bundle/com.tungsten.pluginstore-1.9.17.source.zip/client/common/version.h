// version.h - THE single source of the client version (also read by the
// resource script for the file version, and by installer/get_version.py).
// Rule: bump on EVERY release, never ship an unchanged number.
#pragma once

#define FP_VERSION_MAJOR 1
#define FP_VERSION_MINOR 9
#define FP_VERSION_PATCH 17
#define FP_VERSION_W  L"1.9.17"
#define FP_VERSION_A   "1.9.17"
