Source code of Add-on Store client 1.9.11 (com.tungsten.pluginstore)

Part of: Add-on Store (github.com/mnimtz/pluginstore-powerpdf)
Build: Visual Studio 2022 (v143), Release|x64, Tungsten Power PDF Plugin SDK 2025.3.6
(not included; headers expected under C:\Claude\Documentation\TungstenPowerPDFPluginSDK-2025.3.6).
Run: client\build.cmd, then client\installer\build_msi.cmd (WiX v3).
Package: python tools/make_ppak.py packaging/<spec>.ppakspec.json dist (Add-on Store repository).
